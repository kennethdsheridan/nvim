-- Only required if you have packer configured as `opt`
vim.cmd.packadd('packer.nvim')

return require('packer').startup(function(use)
    -- Packer can manage itself
    use 'wbthomason/packer.nvim'
    -- Install telescope plugin
    use {
        'nvim-telescope/telescope.nvim', -- tag = '0.1.0',
        -- or                            , branch = '0.1.x',
        requires = { { 'nvim-lua/plenary.nvim' } }
    }

    use({
        'rose-pine/neovim',
        as = 'rose-pine',
        config = function()
            vim.cmd('colorscheme rose-pine')
        end
    })


    -- Install nvim-notify for enhanced notifications
    use {
        'rcarriga/nvim-notify',
        config = function()
            vim.notify = require('notify')
        end
    }

    -- Install noice.nvim for configurable views and routing messages
    use {
        'folke/noice.nvim',
        requires = {
            'MunifTanjim/nui.nvim',
            'rcarriga/nvim-notify' -- nvim-notify is optional but recommended for notifications
        },
        config = function()
            require('noice').setup()
            -- Additional noice.nvim setup can be added here
        end
    }

    use {
        'hrsh7th/nvim-cmp',             -- The main nvim-cmp plugin
        requires = {
            'hrsh7th/cmp-buffer',       -- Buffer completions
            'hrsh7th/cmp-path',         -- Path completions
            'hrsh7th/cmp-cmdline',      -- Command line completions
            'saadparwaiz1/cmp_luasnip', -- Snippet completions
            'hrsh7th/cmp-nvim-lsp',     -- LSP completions
            'L3MON4D3/LuaSnip',         -- Snippet engine
            'rafamadriz/friendly-snippets', -- A collection of snippets
            'tzachar/cmp-tabnine',      -- TabNine source for nvim-cmp
            -- Include other completion sources as needed
        },
        config = function()
            -- Your nvim-cmp setup here
        end
    }

    -- Continue with the rest of your packer configuration


    use {
        'tzachar/cmp-tabnine',
        run = './install.sh', -- Use this for Unix-like systems. For Windows, consider 'powershell ./install.ps1'.
        after = 'nvim-cmp',
        requires = {
            'hrsh7th/cmp-buffer',       -- Buffer completions
            'hrsh7th/cmp-path',         -- Path completions
            'hrsh7th/cmp-cmdline',      -- Command line completions
            'saadparwaiz1/cmp_luasnip', -- Snippet completions
            'hrsh7th/cmp-nvim-lsp',     -- LSP completions
            'L3MON4D3/LuaSnip',         -- Snippet engine
            'rafamadriz/friendly-snippets', -- A collection of snippets
        },
        config = function()
            local cmp = require('cmp')
            require('luasnip/loaders/from_vscode').lazy_load() -- Load LuaSnip with friendly snippets

            cmp.setup({
                mapping = {
                    ['<Tab>'] = cmp.mapping.select_next_item({ behavior = cmp.SelectBehavior.Insert }),
                    ['<S-Tab>'] = cmp.mapping.select_prev_item({ behavior = cmp.SelectBehavior.Insert }),
                    ['<CR>'] = cmp.mapping.confirm({ select = true }),
                    -- Include other mappings as needed
                },
                snippet = {
                    expand = function(args)
                        require('luasnip').lsp_expand(args.body) -- Use LuaSnip for expanding snippets
                    end,
                },
                sources = cmp.config.sources({
                    { name = 'cmp_tabnine' }, -- TabNine source
                    { name = 'nvim_lsp' },    -- Neovim's built-in LSP
                    { name = 'luasnip' },     -- LuaSnip source for snippets
                    -- Add other sources as needed
                }),
                -- Include any other configuration for nvim-cmp here
            })

            -- TabNine configuration
            require('cmp_tabnine.config'):setup({
                max_lines = 1000,
                max_num_results = 20,
                sort = true,
                run_on_every_keystroke = true,
                snippet_placeholder = '..',
                show_prediction_strength = false,
            })
        end
    }



    use({
        "folke/trouble.nvim",
        config = function()
            require("trouble").setup {
                icons = false,
                -- your configuration comes here
                -- or leave it empty to use the default settings
                -- refer to the configuration section below
            }
        end
    })

    use {
        'nvim-treesitter/nvim-treesitter',
        run = function()
            local ts_update = require('nvim-treesitter.install').update({ with_sync = true })
            ts_update()
        end, }
    require('packer').startup(function(use)
        -- Enhanced Rust development experience in Neovim
        use {
            'mrcjkb/rustaceanvim',
            version = '^4',
            ft = { 'rust' }
        }

        -- LSP configuration with lsp-zero, mason, and LSP servers
        use {
            'VonHeikemen/lsp-zero.nvim',
            branch = 'v1.x',
            requires = {
                'neovim/nvim-lspconfig',
                'williamboman/mason.nvim',
                'williamboman/mason-lspconfig.nvim',
            },
            config = function()
                local lsp_zero = require('lsp-zero')
                lsp_zero.preset('recommended')
                lsp_zero.setup()
            end
        }

        -- Configure Pyright for Python development
        use {
            'neovim/nvim-lspconfig',
            config = function()
                require 'lspconfig'.pyright.setup({
                    on_attach = function(client, bufnr)
                        -- Add keybindings or additional setup here
                    end,
                    settings = {
                        python = {
                            analysis = {
                                autoSearchPaths = true,
                                diagnosticMode = "workspace",
                                useLibraryCodeForTypes = true
                            },
                            pythonPath = "/usr/local/bin/python3"
                        }
                    }
                })
            end
        }
    end)


    -- The rest of your plugins
    use("nvim-treesitter/playground")
    use("theprimeagen/harpoon")
    use("theprimeagen/refactoring.nvim")
    use("mbbill/undotree")
    use("tpope/vim-fugitive")
    use("nvim-treesitter/nvim-treesitter-context")
    use("folke/zen-mode.nvim")
    use("github/copilot.vim")
    use("eandrju/cellular-automaton.nvim")
    use("laytan/cloak.nvim")
end)
