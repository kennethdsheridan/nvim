-- =====================
-- Cursor and Line Numbers
-- =====================

-- Disable cursor styling provided by the terminal emulator to keep cursor shape consistent.
vim.opt.guicursor = ""

-- Enable line numbers on the left column.
vim.opt.nu = true
-- Show line numbers relative to the line with the cursor for easier line navigation.
vim.opt.relativenumber = true

-- =====================
-- Indentation and Spacing
-- =====================

-- Set the number of spaces that a tab character represents.
vim.opt.tabstop = 4
-- Set the number of spaces to use for autoindenting (inserting a tab).
vim.opt.softtabstop = 4
-- Set the number of spaces to use when performing an indentation.
vim.opt.shiftwidth = 4
-- Convert tabs to spaces. This is useful for keeping indentation consistent across different editors.
vim.opt.expandtab = true

-- Enable smart indentation, which automatically adjusts indentation levels based on the syntax of the code.
vim.opt.smartindent = true

-- Set the text to automatically wrap at 120 characters
vim.opt.textwidth = 120

-- Highlight the 120th column as a visual guideline for text wrapping and line length
vim.opt.colorcolumn = "120"


-- =====================
-- Text Display and Files
-- =====================

-- Disable text wrapping. This makes it easier to navigate long lines of code or text without visual interruption.
vim.opt.wrap = false

-- Disable swap file creation. Swap files are used for recovery purposes but can be disabled if not needed.
vim.opt.swapfile = false
-- Disable backup file creation. Backup files are created before saving a file and can be disabled to keep the directory clean.
vim.opt.backup = false
-- Set the directory for storing undo history, allowing undo operations even after closing and reopening a file.
vim.opt.undodir = os.getenv("HOME") .. "/.vim/undodir"
-- Enable undo file feature, which stores undo history in a file for persistent undo capability.
vim.opt.undofile = true

-- =====================
-- Search
-- =====================

-- Disable highlighting of search matches. This can make the interface cleaner by not persistently highlighting search results.
vim.opt.hlsearch = false
-- Enable incremental search, which shows matches as you type.
vim.opt.incsearch = true

-- =====================
-- Colors and Appearance
-- =====================

-- Enable true color support, allowing for a wider range of colors in the terminal. This enhances the visual appearance of themes.
vim.opt.termguicolors = true

-- Set the number of lines to keep above and below the cursor. This makes reading and navigating code more comfortable.
vim.opt.scrolloff = 8
-- Always display the sign column, where diagnostic signs (errors, warnings) are shown, to avoid shifting text when signs appear.
vim.opt.signcolumn = "yes"
-- Allow '@' and '-' in file names. This enhances compatibility with certain file naming conventions.
vim.opt.isfname:append("@-@")

-- =====================
-- Performance and Responsiveness
-- =====================

-- Set the time Neovim waits after a keystroke before triggering an action (like syntax highlighting). Reducing this value can make Neovim feel more responsive.
vim.opt.updatetime = 50

-- =====================
-- Coding Standards
-- =====================

-- Highlight the 80th column, providing a visual guideline for line length. This is useful for maintaining readability and coding standards.
vim.opt.colorcolumn = "120"

