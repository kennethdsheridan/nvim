--Load essential configurations and plugin initializations.
require("theprimeagen.set")     -- Import custom editor settings (UI, options, etc.).
require("theprimeagen.remap")   -- Load custom key mappings.
require("theprimeagen.packer")  -- Initialize plugins specified in ThePrimeagen's packer config
require("theprimeagen.configs") -- Initialize the configs for the NvChad and Tabnine

-- Import lsp-zero and set preferences
local lsp = require('lsp-zero')

lsp.set_preferences({
    cmp_capabilities = false, -- If you do not have cmp_nvim_lsp installed, set this to false
})

lsp.preset('recommended')

-- Neovim API for creating autogroups, a method to organize autocommands.
local augroup = vim.api.nvim_create_augroup
local ThePrimeagenGroup = augroup('ThePrimeagen', {})

-- Function to attach key mappings and other features when an LSP server attaches to a buffer
local on_attach = function(_, bufnr)
    -- Enable completion triggered by <c-x><c-o>
    vim.api.nvim_buf_set_option(bufnr, 'omnifunc', 'v:lua.vim.lsp.omnifunc')

    -- Define autogroup for highlighting yanked text
    local yank_group = augroup('HighlightYank', {})
    vim.api.nvim_create_autocmd('TextYankPost', {
        group = yank_group,
        callback = function()
            vim.highlight.on_yank({ higroup = 'IncSearch', timeout = 150 })
        end,
    })
end

-- Configure the Pyright language server with specific settings
lsp.pyright.setup({
    settings = {
        python = {
            analysis = {
                autoSearchPaths = true,
            },
        },
    },
    on_attach = on_attach,
})

-- Ensure the installation of language servers for the specified languages
lsp.ensure_installed({
    'rust_analyzer', 'gopls', 'bashls', 'pyright', 'html', 'cssls', 'tsserver',
})

lsp.setup()


-- Utility function for reloading Lua modules, useful during development.
function R(name)
    require("plenary.reload").reload_module(name, true)
end

-- Set column width indicator to 100
vim.opt.colorcolumn = "120"

-- Set up nvim-notify as the default notification library
vim.notify = require("notify")

-- Refactor variable word
vim.api.nvim_set_keymap('n', '<leader>rn', '<cmd>lua vim.lsp.buf.rename()<CR>', { noremap = true, silent = true })

-- Remap for quikcly commenting out a block of text


-- Load and configure Telescope
require('telescope').setup {
    -- Your telescope configuration here
}

-- Ensure the notify extension is loaded as part of Telescope
require('telescope').load_extension('notify')

-- `init.lua` snippet for Neovim using Noice commands

-- Map <leader>nd to dismiss all visible messages
vim.keymap.set("n", "<leader>nd", function()
    require("noice").cmd("dismiss")
end, { desc = "Dismiss all visible Noice messages" })

-- Map <leader>nl to show the last message in a popup
vim.keymap.set("n", "<leader>nl", function()
    require("noice").cmd("last")
end, { desc = "Show last Noice message in a popup" })

-- Map <leader>nh to show message history
vim.keymap.set("n", "<leader>nh", function()
    require("noice").cmd("history")
end, { desc = "Show Noice message history" })

-- Map <leader>ne to show error messages in a split
vim.keymap.set("n", "<leader>ne", function()
    require("noice").cmd("errors")
end, { desc = "Show Noice error messages in a split" })

-- Map <leader>nt to toggle Noice enable/disable
vim.keymap.set("n", "<leader>nt", function()
    local noice = require("noice")
    if noice.is_enabled() then
        noice.cmd("disable")
    else
        noice.cmd("enable")
    end
end, { desc = "Toggle Noice enable/disable" })

-- Map <leader>ns to show Noice stats
vim.keymap.set("n", "<leader>ns", function()
    require("noice").cmd("stats")
end, { desc = "Show Noice debugging stats" })

-- Map <leader>nf to show Noice message history using Telescope
vim.keymap.set("n", "<leader>nf", function()
    require("noice").cmd("telescope")
end, { desc = "Open Noice message history in Telescope" })

-- Documentation for key mappings
-- Using the `desc` field in vim.keymap.set helps document what each mapping does,
-- which can be viewed with `:Telescope keymaps` or other mapping-listing commands.


-- Optional: Keybinding to invoke the Telescope notify extension
vim.api.nvim_set_keymap('n', '<leader>fn', ':Telescope notify<CR>', { noremap = true, silent = true })

-- Set the text to automatically wrap at 120 characters
vim.opt.textwidth = 120

-- Highlight the 120th column as a visual guideline for text wrapping and line length
vim.opt.colorcolumn = "120"

-- Set up a visual mode keymap to comment out selected lines
vim.api.nvim_set_keymap('v', '<leader>c', ':s/^/\\/\\//<CR>', { noremap = true, silent = true })

-- Set the required 24-bit color
vim.opt.termguicolors = true

-- Define the 'LspRestart' command to restart the LSP
vim.api.nvim_create_user_command(
    'LspRestart',
    function()
        -- Stop all LSP clients for the current buffer
        vim.lsp.stop_client(vim.lsp.get_active_clients())
        -- Reload the current buffer to trigger LSP to start again
        vim.cmd('edit')
    end,
    {}
)


-- Define the plugin name for reusability and consistency in notifications.
local plugin = "My Awesome Plugin"

-- Primary notification for an error, using vim.notify function.
-- Displays an error message with a specific format, including a title.
vim.notify("This is an error message.\nSomething went wrong!", "error", {
    title = plugin,
    -- on_open is a callback function that is executed when the notification is opened.
    on_open = function()
        -- Secondary notification indicating an attempt at recovery.
        -- This uses a warning level notification.
        vim.notify("Attempting recovery.", vim.log.levels.WARN, {
            title = plugin,
        })
        -- Initializes a new timer for asynchronous operations.
        local timer = vim.loop.new_timer()
        -- Starts the timer with a delay of 2000 milliseconds (2 seconds), does not repeat.
        timer:start(2000, 0, function()
            -- Notification indicating the start of the problem-fixing process.
            -- It is set to timeout after 3000 milliseconds (3 seconds).
            vim.notify({ "Fixing problem.", "Please wait..." }, "info", {
                title = plugin,
                timeout = 3000,
                -- on_close is a callback that executes when the notification is closed.
                on_close = function()
                    -- Notification indicating the problem has been solved.
                    vim.notify("Problem solved", nil, { title = plugin })
                    -- Additional notification showing an error code, presumably for debugging or logging.
                    -- The log level is set to 1, which typically corresponds to an error.
                    vim.notify("Error code 0x0395AF", 1, { title = plugin })
                end,
            })
        end)
    end,
})


-- Require the 'plenary.async' module to handle asynchronous operations.
local async = require("plenary.async")
-- Require the asynchronous version of the 'notify' function for non-blocking notifications.
local notify = require("notify").async

-- Execute an asynchronous function using 'async.run'.
async.run(function()
    -- Display a notification with the text "Let's wait for this to close".
    -- The '.events.close()' method is called to wait for the notification to be closed before proceeding.
    notify("Let's wait for this to close").events.close()
    -- After the first notification is closed, display a second notification with the text "It closed!".
    notify("It closed!")
end)

-- Use vim.notify to display a notification. The 'text' variable should contain the message you want to display.
vim.notify(text, "info", {
    -- The title of the notification window is set to "My Awesome Plugin".
    title = "My Awesome Plugin",
    -- on_open is a callback function that executes when the notification window is opened.
    on_open = function(win)
        -- Retrieves the buffer associated with the notification window using its window ID.
        local buf = vim.api.nvim_win_get_buf(win)
        -- Sets the filetype of the buffer to "markdown".
        -- This could be useful for rendering the notification's text with markdown formatting,
        -- assuming the notification plugin supports it.
        vim.api.nvim_buf_set_option(buf, "filetype", "markdown")
    end,
})



-- Autocommand to highlight yanked text momentarily.
vim.api.nvim_create_autocmd('TextYankPost', {
    group = yank_group,
    pattern = '*',
    callback = function()
        vim.highlight.on_yank({ higroup = 'IncSearch', timeout = 40 })
    end,
})

-- Autocommand to trim trailing whitespace before saving any file.
vim.api.nvim_create_autocmd("BufWritePre", {
    group = ThePrimeagenGroup,
    pattern = "*",
    command = "%s/\\s\\+$//e",
})

-- Configure the map leader key.
vim.g.mapleader = " "
-- Key mapping for enhancing navigation.
vim.keymap.set("n", "<leader>pv", vim.cmd.Ex)

-- Netrw settings for file exploring.
vim.g.netrw_browse_split = 0
vim.g.netrw_banner = 0
vim.g.netrw_winsize = 25

-- Import nvim-lspconfig
local nvim_lsp = require('lspconfig')

-- Common on_attach function to be used by all LSP servers
local on_attach = function(client, bufnr)
    local bufopts = { noremap = true, silent = true, buffer = bufnr }
    vim.keymap.set('n', 'gd', vim.lsp.buf.definition, bufopts)
    vim.keymap.set('n', 'K', vim.lsp.buf.hover, bufopts)
    vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, bufopts)
    vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, bufopts)
    vim.keymap.set('n', '<leader>ca', vim.lsp.buf.code_action, bufopts)
    vim.keymap.set('n', 'gr', vim.lsp.buf.references, bufopts)
    vim.keymap.set('n', '<leader>f', function() vim.lsp.buf.format({ async = true }) end, bufopts)
end

-- Rust configuration
nvim_lsp.rust_analyzer.setup({
    on_attach = on_attach,
    settings = {
        ["rust-analyzer"] = {
            cargo = { loadOutDirsFromCheck = true },
            procMacro = { enable = true },
            checkOnSave = { command = "clippy" },
        },
    },
})

-- Go configuration
nvim_lsp.gopls.setup({
    on_attach = on_attach,
    settings = {
        gopls = {
            analyses = {
                unusedparams = true,
                shadow = true,
            },
            staticcheck = true,
        },
    },
})


-- Dismiss Noice Message
vim.keymap.set("n", "<leader>nd", "<cmd>NoiceDismiss<CR>", { desc = "Dismiss Noice Message" })


-- Key mapping for copying to the main clipboard using <leader>Y
vim.keymap.set('n', '<leader>Y', '"+y', { noremap = true, silent = true })     -- Copy to clipboard
